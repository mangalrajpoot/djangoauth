from django.shortcuts import render,redirect 
from django.contrib.auth.models import User 
from django.contrib.auth import login,logout,authenticate

# Create your views here.
def index(request):
    if request.method == 'GET':
        return render(request,'app/index.html')
    else:
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        User.objects.create_user(username=username,email=email,password=password)        
        return redirect('login')
    
def userlogin(request):
    if request.method=='GET':
        return render(request,'app/login.html')
    else:
        username=request.POST['username']        
        password=request.POST['password']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('profile')
        else:
            return render(request,'app/login.html')
    

def profile(request):
    if request.user.is_authenticated:
        return render(request,'app/profile.html')
    else:
        return render(request,'app/login.html')
    
def userlogout(request):
    logout(request)
    return redirect('login')
        
    
        


